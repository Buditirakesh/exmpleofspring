package com.example.springexample.exmpleofspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExmpleofspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
