package com.example.springexample.exmpleofspring.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.springexample.exmpleofspring.entity.Server;

@Repository
public interface ServerRepo  extends JpaRepository< Server,Long>{

	
	@Query(value ="SELECT * from server_table where name= 'mvc' ", nativeQuery=true)
	List<Server> getServerByName();
	
	List<Server> findByname(String name);

	List<Server> findBylanguage(String language);

}
