package com.example.springexample.exmpleofspring.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springexample.exmpleofspring.entity.Server;
import com.example.springexample.exmpleofspring.repository.ServerRepo;

@Service
public class ServerServImpl implements ServerService{
	@Autowired ServerRepo repo;

	@Override
	public List<Server> getAllServers() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public String updateServer(Server server, long id) {
		// TODO Auto-generated method stub
		Optional<Server> existingServer = repo.findById(id);
		if(existingServer.isPresent()) {
			Server serve = new Server();
			serve.setName(server.getName());
			serve.setLanguage(server.getLanguage());
			serve.setFramework(server.getFramework());
			repo.save(serve);
			return "Successfully Saved Server";
		}else {
			return "Successfully Not Saved Server";
		}
		
	}

	@Override
	public String deleteServer(long id) {
		// TODO Auto-generated method stub
		repo.deleteById(id);
		return "Successfully deleted Server";
	}

	@Override
	public List<Server> getAllServerByName(String name) {
		// TODO Auto-generated method stub		
		return repo.findByname(name);
	}
	@Override
	public List<Server> getAllServerByLanguage(String language) {
		// TODO Auto-generated method stub		
		return repo.findBylanguage(language);
	}

}
