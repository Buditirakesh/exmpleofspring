package com.example.springexample.exmpleofspring.service;

import java.util.List;

import com.example.springexample.exmpleofspring.entity.Server;

public interface ServerService {
	public List<Server>getAllServers();
	
	public String updateServer(Server server , long id);
	
	public String deleteServer(long id);

	public List<Server> getAllServerByName(String name);

	public List<Server> getAllServerByLanguage(String language);
}
